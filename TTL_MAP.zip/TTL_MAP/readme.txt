This moudle covers testing of Time to expiry for accessing the records in dictionary

Modules:
ttl_operations.py -> It has methods for adding and accessing records
logger.py -> Customized Logger implementation
tests -> This folder contains test script for TTL verification
report -> test execution log files will be dumped in this folder
console.log -> it has console of test execution log 
