import pytest
from TTL_MAP.ttl_operations import TtlOperations
from TTL_MAP.logger import log_capture
from TTL_MAP.logger import end_capture


@pytest.fixture(scope="function")
def test_config():
    """
    This fixture will perform setup and teardown operations
    """
    log_capture('ttl_tests')
    yield TtlOperations()
    end_capture()
