#!/usr/bin/env python

""" TTL Tests class
@b @Description:
Test class covers methods for  test scenarios

@b Usage
Test class and methods can be executed using pytest framework
"""

import time
import pytest
from TTL_MAP.logger import log


@pytest.mark.sanity
def test_get_record_before_expiry(test_config):
    """
    Test steps:
        a. Add rec1 to ttl_map
        b. get the value of rec1 from ttl_map
    """
    key = 'rec1'
    value = 'rec_val1'
    test_config.add_record(key, value, 2)
    record = test_config.get_record(key)
    log.debug("Record accessed successfully")
    assert record == value, "Record accessed successfully"


@pytest.mark.regression
def test_get_record_after_expiry(test_config):
    """
    Test steps:
        a. Add rec1 to ttl_map with ttl value 2secs
        b. Wait for 3secs
        b. Get the value of rec1 from ttl_map
    """
    key = 'rec1'
    test_config.add_record(key, 'rec_val1', 2)
    time.sleep(3)
    record = test_config.get_record(key)
    assert record == -1, "Record was deleted after expiry"


@pytest.mark.regression
def test_get_invalid_record(test_config):
    """
    Test steps:
        a. Try to access rec1 from ttl_map which is empty
        b. Excepted to get an exception
    """
    try:
        test_config.get_record(key=None)
    except Exception:
        log.debug("Try to access record from the empty map, expected to raise an exception")
        assert True, "Tried to access record from empty map"


@pytest.mark.stress
def test_get_multilple_records(test_config):
    """
    Test steps:
    a. Add multiple records to ttl_map with different ttl values
    b. Wait for 3secs
    c. Get the value of rec2 and rec2 from ttl_map
    """
    test_config.add_record('rec1', 'rec_val1', 2)
    test_config.add_record('rec2', 'rec_val2', 1)
    test_config.add_record('rec3', 'rec_val3', 5)
    test_config.add_record('rec4', 'rec_val4', 10)
    time.sleep(3)
    record2 = test_config.get_record('rec2')
    record3 = test_config.get_record('rec3')
    assert record2 == -1, "Record was deleted after expiry"
    assert record3 == 'rec_val3', "Record accessed successfully"
